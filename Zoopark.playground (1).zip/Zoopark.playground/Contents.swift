import UIKit
import Foundation

class Animal {
    private var energy: Int
    private var mass: Int
    private var age = 0
    private let maxAge: Int
    private let name: String
    var isTooOld: Bool {return age >= maxAge}
    
    init (energy: Int, mass: Int, maxAge: Int, name: String) {
        self.energy = energy
        self.mass = mass
        self.maxAge = maxAge
        self.name = name
    }
    
    func getName() -> String {
        return self.name
    }
    func getMaxAge() -> Int {
        return self.maxAge
    }
    
    func info(_ child: Animal) {
        print("Родилось животное! energy = \(child.energy), mass = \(child.mass), max age = \(child.maxAge), name = \(child.name)")
    }
    
    private func tryIncrementAge() {
        if Bool.random() && isTooOld == false && energy > 0 && mass > 0 {
            age += 1
        }
    }
    func sleep() {
        energy += 5
        age += 1
    print("\(name) is sleeping")
    }
    func eating() {
        energy += 3
        mass += 1
        tryIncrementAge()
    print("\(name) is eating")
    }
    func going() {
        energy -= 5
        mass -= 1
        tryIncrementAge()
        print("\(name) is going")
    }
    func pregnant() -> Animal {
        let child = Animal(energy: Int.random(in: 1...10), mass: Int.random(in: 1...5), maxAge: self.maxAge, name: self.name)
        info(child)
        return child
    }
}

class Bird: Animal {
    override func going(){
        super.going()
        print("\(getName()) is flying")
    }
    override func info(_ child: Animal) {
        super.info(child)
        print("Это птица!")
    }
    override func pregnant() -> Animal {
        let child = Bird(energy: Int.random(in: 1...10), mass: Int.random(in: 1...5), maxAge: getMaxAge(), name: getName())
        info(child)
        return child
    }
}
class Fish: Animal {
    override func going(){
        super.going()
        print("\(getName()) is swimming")
    }
    override func info(_ child: Animal) {
        super.info(child)
        print("Это рыба!")
    }
    override func pregnant() -> Animal {
        let child = Fish(energy: Int.random(in: 1...10), mass: Int.random(in: 1...5), maxAge: getMaxAge(), name: getName())
        info(child)
        return child
    }
}
class Dog: Animal {
    override func going() {
        super.going()
        print("\(getName()) is running")
    }
    override func info(_ child: Animal) {
        super.info(child)
        print("Это собака!")
    }
    override func pregnant() -> Animal {
    let child = Dog(energy: Int.random(in: 1...10), mass: Int.random(in: 1...5), maxAge: getMaxAge(), name: getName())
    info(child)
    return child
    }
}

class Bat: Animal {
    override func going() {
        super.going()
        print("\(getName()) is flying")
    }
    override func info(_ child: Animal) {
        super.info(child)
        print("Это летучая мышь!")
    }
    override func pregnant() -> Animal {
    let child = Bat(energy: Int.random(in: 1...10), mass: Int.random(in: 1...5), maxAge: getMaxAge(), name: getName())
    info(child)
    return child
    }
}

class NatureReserve {
    private var animals: Array<Animal>
    
    init (_ animals: [Animal]) {
        self.animals = animals
    }
    func life(_ N: Int) {
        guard animals.count > 0 else { return }
        for _ in 1...N {
            for i in 0...animals.count - 1 {
                let rand = Int.random(in: 1...4)
                switch rand {
                case 1:
                    animals[i].sleep()
                case 2:
                    animals[i].eating()
                case 3:
                    animals[i].going()
                case 4:
                    animals.append(animals[i].pregnant())
                default:
                    print("Ты как сюда попал?")
                }
            }
            animals.filter{$0.isTooOld == false}
            if animals.count == 0 {
                print("Животные вымерли")
                break
            }
        }
        print("Живых животных осталось \(animals.count)")
    }
}

var bird1 = Bird(energy: 4, mass: 3, maxAge: 15, name: "Eagle")
var bird2 = Bird(energy: 5, mass: 3, maxAge: 10, name: "Owl")
var bird3 = Bird(energy: 8, mass: 1, maxAge: 2, name: "Vorobei")
var bird4 = Bird(energy: 2, mass: 2, maxAge: 3, name: "Golub'")
var bird5 = Bird(energy: 3, mass: 2, maxAge: 7, name: "Ptica")
var fish1 = Fish(energy: 9, mass: 4, maxAge: 5, name: "Salmon")
var fish2 = Fish(energy: 8, mass: 5, maxAge: 7, name: "Shark")
var fish3 = Fish(energy: 1, mass: 2, maxAge: 8, name: "Catfish")
var dog1 = Dog(energy: 7, mass: 2, maxAge: 10, name: "Laika")
var dog2 = Dog(energy: 8, mass: 3, maxAge: 13, name: "Balalaika")
var animal1 = Animal(energy: 1, mass: 4, maxAge: 11, name: "Giraffee")
var animal2 = Animal(energy: 3, mass: 5, maxAge: 20, name: "Elephant")
var animal3 = Animal(energy: 7, mass: 1, maxAge: 7, name: "Rat")
var bat1 = Bat(energy: 4, mass: 1, maxAge: 8, name: "Batman")
var bat2 = Bat(energy: 5, mass: 2, maxAge: 9, name: "Joker")
var bat3 = Bat(energy: 6, mass: 3, maxAge: 10, name: "Catwoman")

let example: [Animal] = [bird1, bird2, bird3, bird4, bird5, fish1, fish2, fish3, dog1, dog2, animal1, animal2, animal3, bat1, bat2, bat3]

let reservation = NatureReserve(example)

reservation.life(10)

